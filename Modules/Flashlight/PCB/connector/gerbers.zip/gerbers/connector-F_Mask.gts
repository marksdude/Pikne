%TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*%
%TF.CreationDate,2026-08-26T20:09:02+03:00*%
%TF.ProjectId,connector,636f6e6e-6563-4746-9f72-2e6b69636164,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-08-26 20:09:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.200000*%
%ADD11C,1.000000*%
%ADD12RoundRect,0.112500X0.350000X0.112500X-0.350000X0.112500X-0.350000X-0.112500X0.350000X-0.112500X0*%
%ADD13C,1.800000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X176750000Y-99700000D03*
%TD*%
D11*
%TO.C,TP3*%
X167000000Y-96800000D03*
%TD*%
%TO.C,TP2*%
X162600000Y-101100000D03*
%TD*%
D12*
%TO.C,U1*%
X162587500Y-99600000D03*
X162587500Y-98300000D03*
X160812500Y-98950000D03*
%TD*%
D10*
%TO.C,REF\u002A\u002A*%
X157250000Y-99700000D03*
%TD*%
D11*
%TO.C,TP1*%
X162600000Y-96800000D03*
%TD*%
D13*
%TO.C,J1*%
X169300000Y-99700000D03*
X167000000Y-99700000D03*
X164700000Y-99700000D03*
%TD*%
M02*
